(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9dc56dc0._.js",
  "static/chunks/[root-of-the-server]__c51c5f5f._.js",
  "static/chunks/[root-of-the-server]__78d94ec3._.css"
],
    source: "dynamic"
});
