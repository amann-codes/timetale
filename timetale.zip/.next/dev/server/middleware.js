var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/node_modules_next_1596a6e4._.js")
R.c("server/chunks/97170_@auth_core_27f06d8f._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_d921b6a6._.js")
R.c("server/chunks/node_modules_d25fd90b._.js")
R.c("server/chunks/[root-of-the-server]__39a75726._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)").exports
